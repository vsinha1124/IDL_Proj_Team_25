#!/usr/bin/env python3
"""
Simple script to read and display HumanEval results
"""

import json
import sys
import os

def print_results(file_path):
    """Read and display HumanEval results from a JSONL file"""
    
    # Check if file exists
    if not os.path.exists(file_path):
        print(f"Error: File not found: {file_path}")
        return
    
    # Read the file
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    # Parse each line as JSON
    results = []
    for line in lines:
        try:
            result = json.loads(line.strip())
            results.append(result)
        except json.JSONDecodeError as e:
            print(f"Error parsing line: {e}")
            continue
    
    # Display summary
    total = len(results)
    passed = sum(1 for r in results if r.get('passed', False))
    pass_rate = (passed / total * 100) if total > 0 else 0
    
    print("\n===== RESULTS SUMMARY =====")
    print(f"Total problems: {total}")
    print(f"Passed: {passed}")
    print(f"Failed: {total - passed}")
    print(f"Pass rate: {pass_rate:.2f}%")
    
    # Display individual results
    print("\n===== DETAILED RESULTS =====")
    for result in results:
        task_id = result.get('task_id', 'Unknown')
        status = "✓ PASSED" if result.get('passed', False) else "✗ FAILED"
        error = result.get('result', '')
        if not result.get('passed', False) and error != "passed":
            if error.startswith("failed: "):
                error = error[8:]  # Remove "failed: " prefix
            error_msg = f"\n   Error: {error}" if error else ""
        else:
            error_msg = ""
            
        print(f"{task_id}: {status}{error_msg}")

if __name__ == "__main__":
    # Default to the results file if no argument is provided
    file_path = "humaneval_samples.jsonl_results.jsonl"
    
    # If a file path is provided as an argument, use that instead
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    
    print(f"Reading results from: {file_path}")
    print_results(file_path)